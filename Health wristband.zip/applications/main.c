/*
 * Copyright (c) 2006-2022, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-05-11     RT-Thread    first version
 */

#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "mlx90615.h"
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

static struct rt_semaphore rx_sem;
static rt_device_t serial = NULL;
struct rt_ringbuffer * rx_rb;

static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    char ch;
    rt_device_read(serial, -1, &ch, 1);
    rt_ringbuffer_putchar(rx_rb, ch);//把数据压进队列,否会丢失数据
    rt_sem_release(&rx_sem);
    return RT_EOK;
}

static void serial_thread_rx(void *parameter)
{
    char ch;
    while (1){
        rt_sem_take(&rx_sem, RT_WAITING_FOREVER);
        while(rt_ringbuffer_getchar(rx_rb, &ch)){//读出串口队列数据
            rt_kprintf("%c", ch);
            //进行蓝牙命解释
        }
    }
}

struct serial_configure config = {
        BAUD_RATE_38400,
        DATA_BITS_8,
        STOP_BITS_1,
        PARITY_NONE,
        BIT_ORDER_LSB,
        NRZ_NORMAL,
        RT_SERIAL_RB_BUFSZ,
        0
};

static void uart_rx(int argc, char **argv)
{
    if(argc<2){
        rt_kprintf("uart_rx [device]\r\n");
        return;
    }
    char *uart_name = argv[1];

    rx_rb = rt_ringbuffer_create(64);

    serial = rt_device_find(uart_name);
    if (!serial){
        rt_kprintf("find %s failed!\n", uart_name);
        return;
    }

    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);
    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_set_rx_indicate(serial, uart_input);

    rt_thread_t thread = rt_thread_create("serial_rx", serial_thread_rx, RT_NULL, 1024, 25, 10);
    rt_thread_startup(thread);
}

static void uart_tx(int argc, char **argv)
{
    if(argc<2){
        rt_kprintf("uart_tx [data]\r\n");
        return;
    }
    if(!serial){
        rt_kprintf("serial(null)\r\n");
        return;
    }
    char buf[64];
    //rt_kprintf("uart tx:%s\r\n", argv[1]);
    sprintf(buf, "AT+SEND=%d\r\n", strlen(argv[1]));
    rt_device_write(serial, 0, buf, strlen(buf));
    rt_thread_mdelay(1);
    rt_device_write(serial, 0, argv[1], strlen(argv[1]));
    rt_device_write(serial, 0, "\r\n", 2);
}

void mlx_test(int argc, char **argv)
{
 int j=0;
    if(argc<2){
        rt_kprintf("mlx_test [n]\r\n");
        return;
    }
    int n = atoi(argv[1]);
    mlx90615_init();
    while(n--){
        float temp,temp1=0;

       for(j=0;j<10;j++)
       {
        mlx90615_GetTemp(&temp);
        temp1+=temp;
       }
       temp=temp1/j+6;
        rt_kprintf("%.1f\r\n", temp);
        if(serial){
            char buf[64];
            char tmpstr[64];
            sprintf(tmpstr, "{\"A0\":%.1f}", temp);
            sprintf(buf, "AT+SEND=%d\r\n", strlen(tmpstr));
            rt_device_write(serial, 0, buf, strlen(buf));
            rt_thread_mdelay(1);
            rt_device_write(serial, 0, tmpstr, strlen(tmpstr));
            rt_device_write(serial, 0, "\r\n", 2);
        }
        rt_thread_mdelay(1000);
    }
}

int main(void)
{

    return RT_EOK;
}

MSH_CMD_EXPORT(uart_rx, uart rx);//先运行,测试蓝牙接收
MSH_CMD_EXPORT(uart_tx, uart tx);//测试发送
MSH_CMD_EXPORT(mlx_test, mlx test);//测试温度
