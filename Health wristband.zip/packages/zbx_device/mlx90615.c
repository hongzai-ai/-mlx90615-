#include <rtthread.h>
#include <board.h>
#include "soft_iic.h"
#include "mlx90615.h"

#define DEV_ADDR 0x5B
#define EE_ADDR(x)        ((0x01<<4)|((x)&0x0f))
#define RAM_ADDR(x)       ((0x02<<4)|((x)&0x0f))

void mlx90615_smb(void)
{
    SCL1_L;
    rt_thread_mdelay(50);
    SCL1_H;
}

int mlx90615_read(char reg, char *buf, int len)
{
  int i;
  I2C1_Start();
  I2C1_WriteByte(DEV_ADDR<<1 | 0);
  if (I2C1_WaitAck()) 
  {
    return -1;
  }
  I2C1_WriteByte(reg);
  if (I2C1_WaitAck()) 
  {
    return -1;
  }
  I2C1_Start();
  I2C1_WriteByte(DEV_ADDR<<1 | 1);
  if (I2C1_WaitAck()) 
  {
    return -1;
  }
  for (i=0; i<len-1; i++) 
  {
    buf[i] = I2C1_ReadByte();
    I2C1_Ack();
  }
  buf[i] = I2C1_ReadByte();
  I2C1_NoAck();
  I2C1_Stop();
  return 1;
}


int mlx90615_init()
{
  char id[2] = {0, 0};
  I2C1_GPIOInit();
  
  mlx90615_smb();
  
  if (mlx90615_read(EE_ADDR(0x0e), id, 2) != 1) 
  {
    rt_kprintf("error: can't find ic mlx90615 \r\n");
    return -1;
  }
  else
  {
    rt_kprintf("mlx90615 id : %02X%02X\r\n", id[0], id[1]);
    return 0;
  }
}

short mlx90615_GetTemp(float* temp)
{
  char buf[2];
  if (mlx90615_read(RAM_ADDR(0x07), buf, 2) == 1)
  {
    unsigned int value = buf[1]<<8 | buf[0];
    *temp = (value*0.02)-273.15;
    return 0;
  }
  return -1;
}
