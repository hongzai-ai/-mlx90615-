#ifndef _soft_iic_
#define _soft_iic_

#include <rtdevice.h>

void IIC_DelayUs(uint16_t t);

/**********************************************************************************************/
//I2C
#define I2C_SCL GET_PIN(A, 8)
#define I2C_SDA GET_PIN(C, 9)

#define SCL_L  rt_pin_write(I2C_SCL, 0)
#define SCL_H  rt_pin_write(I2C_SCL, 1)

#define SDA_L  rt_pin_write(I2C_SDA, 0)
#define SDA_H  rt_pin_write(I2C_SDA, 1)

#define SDA_R rt_pin_read(I2C_SDA)

#define SDA_OUT
#define SDA_IN

void I2C_GPIOInit(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Ack(void);
void I2C_NoAck(void);
int I2C_WaitAck(void);
void I2C_WriteByte(uint8_t SendByte); //数据从高位到低位
uint8_t I2C_ReadByte(void);

/**********************************************************************************************/
//I2C1
#define I2C1_SCL GET_PIN(A, 6)
#define I2C1_SDA GET_PIN(A, 5)

#define SCL1_L  rt_pin_write(I2C1_SCL, 0)
#define SCL1_H  rt_pin_write(I2C1_SCL, 1)

#define SDA1_L  rt_pin_write(I2C1_SDA, 0)
#define SDA1_H  rt_pin_write(I2C1_SDA, 1)

#define SDA1_R rt_pin_read(I2C1_SDA)

#define SDA1_OUT
#define SDA1_IN

void I2C1_GPIOInit(void);
void I2C1_Start(void);
void I2C1_Stop(void);
void I2C1_Ack(void);
void I2C1_NoAck(void);
int I2C1_WaitAck(void);
void I2C1_WriteByte(uint8_t SendByte); //���ݴӸ�λ����λ
uint8_t I2C1_ReadByte(void);

/**********************************************************************************************/
//I2C2
#define I2C2_SCL GET_PIN(B, 8)
#define I2C2_SDA GET_PIN(B, 9)

#define SCL2_L  rt_pin_write(I2C2_SCL, 0)
#define SCL2_H  rt_pin_write(I2C2_SCL, 1)

#define SDA2_L  rt_pin_write(I2C2_SDA, 0)
#define SDA2_H  rt_pin_write(I2C2_SDA, 1)

#define SDA2_R rt_pin_read(I2C2_SDA)

#define SDA2_OUT
#define SDA2_IN

void I2C2_GPIOInit(void);
void I2C2_Start(void);
void I2C2_Stop(void);
void I2C2_Ack(void);
void I2C2_NoAck(void);
int I2C2_WaitAck(void);
void I2C2_WriteByte(uint8_t SendByte); //数据从高位到低位
uint8_t I2C2_ReadByte(void);

#endif
