#include <rtthread.h>
#include <board.h>
#include "soft_iic.h"

void IIC_DelayUs(uint16_t us)
{
    rt_uint32_t ticks;
    rt_uint32_t told, tnow, tcnt = 0;
    rt_uint32_t reload = SysTick->LOAD;

    ticks = us * reload / (1000000 / RT_TICK_PER_SECOND);
    told = SysTick->VAL;
    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }
}

void I2C1_GPIOInit(void)
{
  rt_pin_mode(I2C1_SCL, PIN_MODE_OUTPUT_OD);
  rt_pin_mode(I2C1_SDA, PIN_MODE_OUTPUT_OD);
  SDA1_H;
  SCL1_H;
}

void I2C1_Start(void)
{
  SDA1_OUT;
  SDA1_H;
  SCL1_H;
  IIC_DelayUs(20);
  SDA1_L;
  IIC_DelayUs(20);
  SCL1_L;
}

void I2C1_Stop(void)
{
  SDA1_OUT;
  SCL1_L;
  SDA1_L;
  IIC_DelayUs(20);
  SCL1_H;
  SDA1_H;
  IIC_DelayUs(20);
}

void I2C1_Ack(void)
{
  SCL1_L;
  SDA1_OUT;
  SDA1_L;
  IIC_DelayUs(20);
  SCL1_H;
  IIC_DelayUs(20);
  SCL1_L;
}

void I2C1_NoAck(void)
{
  SCL1_L;
  SDA1_OUT;
  SDA1_H;
  IIC_DelayUs(20);
  SCL1_H;
  IIC_DelayUs(20);
  SCL1_L;
}

int I2C1_WaitAck(void)
{
  uint8_t ucErrTime=0;
  SDA1_H;
  IIC_DelayUs(20);
  SDA1_IN;
  SCL1_H;
  IIC_DelayUs(20);
  while (SDA1_R)
  {
    ucErrTime++;
    if(ucErrTime>250)
    {
      I2C1_Stop();
      return 1;
    }
  }
  SCL1_L;
  return 0;
}

void I2C1_WriteByte(uint8_t SendByte) //数据从高位到低位//
{
  uint8_t i=8;
  SDA1_OUT;
  while(i--)
  {
    if(SendByte&0x80) SDA1_H;
    else SDA1_L;
    SendByte<<=1;
    IIC_DelayUs(10);
    SCL1_H;
    IIC_DelayUs(20);
    SCL1_L;
    IIC_DelayUs(10);
  }
  SDA1_H;
}

uint8_t I2C1_ReadByte(void)
{
  uint8_t i=8;
  uint8_t ReceiveByte=0;

  SDA1_H;
  SDA1_IN;
  while(i--)
  {
    ReceiveByte<<=1;
    SCL1_L;
    IIC_DelayUs(20);
    SCL1_H;
    IIC_DelayUs(20);
    if(SDA1_R)
    {
      ReceiveByte|=0x01;
    }
  }
  SCL1_L;
  return ReceiveByte;
}
