/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 */
#ifndef __DFS_JFFS2_H__ 
#define __DFS_JFFS2_H__

int dfs_jffs2_init(void);

#endif
