#ifndef __LINUX_VERSION_H__
#define __LINUX_VERSION_H__

#include <rtthread.h>

#endif /* __LINUX_VERSION_H__ */
