package com.scott.myapplication.ui.home;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.scott.myapplication.utils.BLEUtils;
import com.scott.myapplication.databinding.FragmentHomeBinding;
import com.scott.myapplication.utils.TcpUtils;
import com.scott.myapplication.utils.ZyUtils;

import java.util.UUID;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    BluetoothAdapter bluetoothAdapter;
    HomeViewModel homeViewModel;
    BLEUtils mBLEUtils;
    TcpUtils tcp;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final EditText editView = binding.editTextTextMultiLine;
        final TextView textView = binding.textHome;
        textView.setMovementMethod(ScrollingMovementMethod.getInstance());
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        setBroadcastReceiver();
        mBLEUtils = new BLEUtils(requireContext());
        ZyUtils zyUtils = new ZyUtils((status, result) -> {
            homeViewModel.addText(result);
            return true;
        });

        Log.d("SCOTT_LOG", "initBle");
        if(!mBLEUtils.initBle()){
            return root;
        }

        binding.button.setOnClickListener(view -> {
            /*if(!mBLEUtils.isConnected()) {
                mBLEUtils.scanBle();
                Log.d("SCOTT_LOG", "scanBle");
            }*/

            //zyUtils.write(editView.getText().toString());
            zyUtils.query("00:12:4B:00:02:63:3C:4F_A0", "", "");

            //homeViewModel.addText("Hello " + tcp.result);
        });
        return root;
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address

                homeViewModel.addText(deviceName + ": " + deviceHardwareAddress);

                if (deviceName != null && deviceName.equals("ZXBeeBLEPeripheral")) {
                    mBLEUtils.stopscanBle();
                    if(mBLEUtils.conectBle(device)) {
                        homeViewModel.addText("正在连接...");
                        mBLEUtils.mBluetoothGatt.discoverServices();
                    }
                }
            }else if (BLEUtils.ACTION_ServicesDiscovered_OVER.equals(action)) {
                homeViewModel.zero();
                /* 设置蓝牙串口通知 */
                UUID su = UUID.fromString("0000aaa0-0000-1000-8000-00805f9b34fb");
                UUID cu = UUID.fromString("0000aaa1-0000-1000-8000-00805f9b34fb");

                BluetoothGattService bgs = mBLEUtils.mBluetoothGatt.getService(su);
                BluetoothGattCharacteristic c = bgs.getCharacteristic(cu);
                //BluetoothGattCharacteristic c = new BluetoothGattCharacteristic(x, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_READ);
                mBLEUtils.mBluetoothGatt.setCharacteristicNotification(c, true);

                BluetoothGattDescriptor descriptor = c.getDescriptor(UUID
                        .fromString("00002902-0000-1000-8000-00805f9b34fb"));
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                mBLEUtils.mBluetoothGatt.writeDescriptor(descriptor);
            }else if (BLEUtils.ACTION_DATA_CHANGE.equals(action)) {
                byte[] dat = intent.getByteArrayExtra("value");
                homeViewModel.addText(dat.toString());
            }
        }
    };

    private void setBroadcastReceiver() {
        // 创建一个IntentFilter对象，将其action指定为BluetoothDevice.ACTION_FOUND
        IntentFilter intentFilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);

        intentFilter.addAction(BLEUtils.ACTION_READ_Descriptor_OVER);

        intentFilter.addAction(BLEUtils.ACTION_STATE_CONNECTED);
        intentFilter.addAction(BLEUtils.ACTION_STATE_DISCONNECTED);
        intentFilter.addAction(BLEUtils.ACTION_ServicesDiscovered_OVER);

        intentFilter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);

        intentFilter.addAction(BLEUtils.ACTION_DATA_CHANGE);
        intentFilter.addAction(BLEUtils.ACTION_WRITE_OVER);
        intentFilter.addAction(BLEUtils.ACTION_RSSI_READ);
        // 注册广播接收器
        requireContext().registerReceiver(receiver, intentFilter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        requireContext().unregisterReceiver(receiver);
    }
}