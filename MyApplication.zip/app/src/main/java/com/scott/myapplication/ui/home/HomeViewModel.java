package com.scott.myapplication.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        zero();
    }

    public LiveData<String> getText() {
        return mText;
    }

    public void addText(String value) {
        mText.setValue(value + "\n" + mText.getValue());
    }

    public void postText(String value) {
        mText.postValue(value + "\n" + mText.getValue());
    }

    public void zero() {
        mText.setValue("\n↑\n调试信息\n");
    }
}