package com.scott.myapplication.utils;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;


public class BLEUtils {

    public BluetoothManager mBluetoothManager;
    public BluetoothAdapter mBluetoothAdapter;
    public BluetoothGatt mBluetoothGatt;
    private boolean connect_flag = false;

    private final Context context;

    public BLEUtils(Context context) {
        this.context = context;
    }

    // 初始化BLE
    public boolean initBle() {
        mBluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);

        if (null == mBluetoothManager) {
            return false;
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        //mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return null != mBluetoothAdapter;
    }

    // 扫描
    public void scanBle() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            Log.d("SCOTT_LOG", "scanBle 1");
            mBluetoothAdapter.getBluetoothLeScanner().startScan(new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {

                    int rssi = result.getRssi();
                    BluetoothDevice dev = result.getDevice();
                    byte[] scanRecord = result.getScanRecord().getBytes();

                    Log.d("SCOTT_LOG", "Rssi: " + rssi + "; Record" + scanRecord.toString());
                    //broadcastUpdate(ACTION_R1EAD_OVER, dev);
                }
            });
            Log.d("SCOTT_LOG", "scanBle 2");
        }
    }

    // 停止扫描
    public void stopscanBle() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            mBluetoothAdapter.cancelDiscovery();
        }
    }

    // 发起连接
    public boolean conectBle(BluetoothDevice mBluetoothDevice) {
        disConectBle();

        BluetoothDevice device_tmp = mBluetoothAdapter.getRemoteDevice(mBluetoothDevice.getAddress());
        if (device_tmp == null) {
            System.out.println("device 不存在");
            return false;
        }


        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            mBluetoothGatt = device_tmp.connectGatt(context, false, mGattCallback);
        }
        return true;
    }

    // 关闭连接
    public void disConectBle() {
        if (mBluetoothGatt != null) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                mBluetoothGatt.disconnect();
                mBluetoothGatt.close();
            }
            mBluetoothGatt = null;
            connect_flag = false;
        }
    }

    // 检查是否连接
    public boolean isConnected() {
        return connect_flag;
    }

    // 发送广播消息
    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        context.sendBroadcast(intent);
    }

    // 发送广播消息
    private void broadcastUpdate(final String action, int value) {
        final Intent intent = new Intent(action);
        intent.putExtra("value", value);
        context.sendBroadcast(intent);
    }

    // 发送广播消息
    private void broadcastUpdate(final String action, byte[] value) {
        final Intent intent = new Intent(action);
        intent.putExtra("value", value);
        context.sendBroadcast(intent);
    }

    // 发送广播消息
    private void broadcastUpdate(final String action, BluetoothDevice value) {
        final Intent intent = new Intent(action);
        intent.putExtra("value", value);
        context.sendBroadcast(intent);
    }

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) { // 链接成功
                System.out.println("CONNECTED");
                connect_flag = true;
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    mBluetoothGatt.discoverServices();
                }
                broadcastUpdate(ACTION_STATE_CONNECTED);

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) { // 断开链接
                System.out.println("UNCONNECTED");
                connect_flag = false;
                broadcastUpdate(ACTION_STATE_DISCONNECTED);
            }

        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                System.out.println("onServicesDiscovered");
                broadcastUpdate(ACTION_ServicesDiscovered_OVER, status);
            }
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt,
                                     BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);

            broadcastUpdate(ACTION_READ_Descriptor_OVER, status);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);

            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_READ_OVER, characteristic.getValue());
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            broadcastUpdate(ACTION_DATA_CHANGE, characteristic.getValue());
        }


        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt,
                                          BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            broadcastUpdate(ACTION_WRITE_OVER, status);
        }

    };


    private final static String CLASS_PATH = "com.scott.myapplication.utils.BLEService.";
    public  final static String ACTION_DATA_CHANGE = CLASS_PATH + "ACTION_DATA_CHANGE";
    public  final static String ACTION_RSSI_READ = CLASS_PATH + "ACTION_RSSI_READ";
    public  final static String ACTION_STATE_CONNECTED = CLASS_PATH + "ACTION_STATE_CONNECTED";
    public  final static String ACTION_STATE_DISCONNECTED = CLASS_PATH + "ACTION_STATE_DISCONNECTED";
    public  final static String ACTION_WRITE_OVER = CLASS_PATH + "ACTION_WRITE_OVER";
    public  final static String ACTION_READ_OVER = CLASS_PATH + "ACTION_READ_OVER";
    public  final static String ACTION_READ_Descriptor_OVER = CLASS_PATH + "ACTION_READ_Descriptor_OVER";
    public  final static String ACTION_WRITE_Descriptor_OVER = CLASS_PATH + "ACTION_WRITE_Descriptor_OVER";
    public  final static String ACTION_ServicesDiscovered_OVER = CLASS_PATH + "ACTION_ServicesDiscovered_OVER";
}
