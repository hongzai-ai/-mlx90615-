package com.scott.myapplication.utils;

public interface Callback {
    boolean tcp(String status, String result);
}
