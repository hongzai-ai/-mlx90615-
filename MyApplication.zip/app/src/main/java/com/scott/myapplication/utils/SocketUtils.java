package com.scott.myapplication.utils;

import java.net.Socket;
import java.util.HashMap;

public class SocketUtils {
    private final HashMap<String, Socket> sockets;

    public SocketUtils() {
        sockets = new HashMap<>();
    }


}
