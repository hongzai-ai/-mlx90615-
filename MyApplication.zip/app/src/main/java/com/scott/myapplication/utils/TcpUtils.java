package com.scott.myapplication.utils;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.CharBuffer;
import java.util.AbstractQueue;
import java.util.Queue;
import java.util.concurrent.LinkedTransferQueue;

public class TcpUtils extends Thread{
    protected Socket socket;
    protected String status;
    protected BufferedWriter bWriter;
    protected BufferedReader bReader;
    protected LinkedTransferQueue<String> wline;
    protected String rline;
    protected char[] rchars;
    protected int rlen;
    protected long write_time;

    protected String host;
    protected int port;

    protected final Thread wThread;
    private final Handler handle;
    protected Callback callback;
    protected boolean isRun;

    public TcpUtils (Callback callback) {
        this();
        this.callback = callback;
    }

    public TcpUtils() {
        rchars = new char[512];
        wline = new LinkedTransferQueue<>();
        wThread = new Thread(() -> { while (isRun) {
            if(bWriter == null) continue;
            //if(wline.isEmpty()) t_wait();
            if(wline.isEmpty()) continue;
            try {
                bWriter.write(wline.poll());
                bWriter.newLine();
                bWriter.flush();
                write_time = System.currentTimeMillis();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }});
        handle = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                if(callback == null) return;
                Bundle bundle = msg.getData();
                String status = bundle.getString("status");
                String result = bundle.getString("result");
                callback.tcp(status, result);
            }
        };
    }

    public void connect(String host, int port) {
        this.host = host;
        this.port = port;
        isRun = true;
        this.start();
        wThread.start();
    }

    public boolean write(String line) {
        if(bWriter == null) return false;
        else return wline.offer(line);
    }

    public void close() {
        isRun = false;
    }

    protected void send(String status, String result) {
        Message message = new Message();
        Bundle bundle = new Bundle();
        bundle.putString("status", status);
        bundle.putString("result", result);
        message.setData(bundle);
        handle.sendMessage(message);
    }

    protected void t_connect() {
        if (socket != null) return;
        try {
            socket = new Socket(host, port);
            bWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            bReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void t_read() {
        try {
            while ((rlen = bReader.read(rchars)) > 0) {
                rline = new String(rchars, 0, rlen);
                send(status, rline);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void t_close() {
        try {
            bWriter.close();
            bReader.close();
            socket.close();
            socket = null;
            bWriter = null;
            bReader = null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void t_wait() {
        //
    };

    @Override
    public void run() {
        while (isRun) {
            t_connect();
            t_read();
        }
    }
}
