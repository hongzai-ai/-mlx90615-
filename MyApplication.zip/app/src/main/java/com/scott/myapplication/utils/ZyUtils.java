package com.scott.myapplication.utils;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

public class ZyUtils extends TcpUtils {
    public final static String HOST = "api.zhiyun360.com";
    public final static int RT_PORT = 8080;
    public final static String UID = "730216445855";
    public final static String KEY = "BgcIBwZQBAYGD1ZTYFpeVl5BRzw";

    private final static int ECHO_TIME = 5*1000;
    private long echo_seq;

    public ZyUtils() {
        super();
        connect(HOST, RT_PORT);
    }

    public ZyUtils(Callback callback) {
        super(callback);
        connect(HOST, RT_PORT);
    }

    @Override
    protected void t_connect() {
        super.t_connect();
        //verify();
    }

    public void write(String line, Callback callback) {
        this.callback = callback;
        if(!write(line)) send("POST_ZY", "请稍后重试");
    }

    public void query(String ch, String st, String et, Callback callback) {
        this.callback = callback;
        query(ch, st, et);
    }

    public void query(String ch, String st, String et) {
        write("GET http://api.zhiyun360.com:8080/v2/feeds/730216445855/datastreams/00:12:4B:00:02:63:3C:4F_A0?duration=6hours\r\n");

    }

    @Override
    protected void t_wait() {
        if(System.currentTimeMillis()-write_time < ECHO_TIME) return;
        try {
            JSONObject cmd = new JSONObject();
            cmd.put("method", "echo");
            cmd.put("timestamp", System.currentTimeMillis());
            cmd.put("seq", ++echo_seq);
            write(cmd.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void verify() {
        try {
            JSONObject cmd = new JSONObject();
            cmd.put("method", "authenticate");
            cmd.put("uid", UID);
            cmd.put("key", KEY);
            cmd.put("version", "0.1.0");
            cmd.put("autodb", "true");
            write(cmd.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
